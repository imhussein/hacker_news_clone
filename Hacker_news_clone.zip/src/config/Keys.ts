/**
 * App Config
 */
export enum Keys {
  apiEndpoint = "https://hacker-news.firebaseio.com/v0",
  topArticles = "topstories.json",
  newArticles = "newstories.json",
}
