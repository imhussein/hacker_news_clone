/**
 * App Actions
 * @description Actions Constants Used For State Management
 */

export enum Actions {
  GET_NEW_ARTICLES = "GET_NEW_ARTICLES",
  GET_TOP_ARTICLES = "GET_TOP_ARTICLES",
}
