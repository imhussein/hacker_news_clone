import ReactDOM from "react-dom";
import React from "react";
import App from "./App";
import "./assets/sass/main.scss";

ReactDOM.render(<App />, document.getElementById("root"));
